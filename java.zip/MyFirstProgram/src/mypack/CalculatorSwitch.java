package mypack;
import java.util.Scanner;
public class CalculatorSwitch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		
		//Input two numbers
		System.out.println("Enter First number");
		double num1;
		num1=sc.nextDouble();
		
		System.out.println("Enter Second number");
		double num2;
		num2=sc.nextDouble();
		
		//Show operation choices
		
		System.out.println("---- Choose an operation: ----  ");
		System.out.println("+ for Addition");
		System.out.println("- for Substraction");
		System.out.println("* for Multiplication");
		System.out.println("/ for Division");
		
		
		//Input operator
		
		System.out.println("Enter your choice");
		char operator;
		operator=sc.next().charAt(0);
		
		//for result stored
		double result;
		
		
		
		//Switch case performance operations
		
		switch(operator) {
		case'+':
			result=num1+num2;
			System.out.println("Result = "+result);
			break;
		case'-':
			result=num1-num2;
			System.out.println("Result = "+result);
			break;
		case'*':
			result=num1*num2;
			System.out.println("Result = "+result);
			break;
		case'/':
			//Check for division by zero
			
			if(num2!=0) {
				result=num1/num2;
				System.out.println("Result ="+result);
			}
			else {
				
				System.out.println("Error ! division by zero is not allowed");
				}
			
			break;
			
		default :
			System.out.println("Invalid operator! Please choose +, -, *, or /.");
			
			

			
		
			
			
		}
		sc.close();
	}

}
