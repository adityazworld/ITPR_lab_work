package mypack;
import java.util.Scanner;
public class Maths {

	public static void main(String[] args) {
		   /*Hypotenenuse 
             c=sqrt((x*x)+(y*y)*/
		double x;
		double y;
		double z;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the side x:");
		x=sc.nextDouble();
		System.out.println("Enter the side y:");
		y=sc.nextDouble();
		
		z=Math.sqrt((x*x)+(y*y));
		System.out.println("The hypotenuse is :"+z);
		sc.close();
		

	}

}
