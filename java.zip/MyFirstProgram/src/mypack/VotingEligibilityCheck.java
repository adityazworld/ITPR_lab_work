package mypack;
import java.util.Scanner;
public class VotingEligibilityCheck {

	public static void main(String[] args) {
	    //To get input from user
		Scanner sc=new Scanner(System.in);
		
		System.out.println("-----Voting Eligibility check-----");
		
		
		//using try and catch for exception handle
		
		try {
			System.out.println("Enter your age");
			
			int age=sc.nextInt();
			
			//use conditional statement for logic for voting
			
			if(age<0) {
				System.out.println("You are not adult");
			}
			else if(age>=18) {
				System.out.println("You are adult");
				
			}
			else {
				System.out.println("You are not eligible");
			}
		}
		catch (java.util.InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid Age.");
		} finally {
            // close the scanner
            sc.close();
        }
	}

}
