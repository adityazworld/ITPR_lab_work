package mypack;
import java.util.Scanner;
public class Switch {

	public static void main(String[] args) {
		
		// switch= satatement that allows a variable to be tested for equality against a list of values
          
		Scanner sc=new Scanner(System.in);
		
		  int day;
		  System.out.println("Enter a number(1 to 7):");
		  day=sc.nextInt();
		  
		  
		  switch(day){
			  case 1:
				  System.out.println("It is Sunday");
			  break;
			  case 2:
				  System.out.println("It is Monday");
			  break;
			  case 3:
				  System.out.println("It is Tuesday");
			  break;
			  case 4:
				  System.out.println("It is Wedsesday");
			  break;
			  case 5:
				  System.out.println("It is Thursday");
			  break;
			  case 6:
				  System.out.println("It is Friday");
			  break;
			  case 7:
				  System.out.println("It is Saturday");
			  break;
			  default: System.out.println("Invalid day number? Please enter no. 1 to 7 ");
		  }
		  sc.close();
	}

}
