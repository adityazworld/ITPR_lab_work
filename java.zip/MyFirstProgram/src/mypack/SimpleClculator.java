package mypack;
import java.util.Scanner;
public class SimpleClculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   /*A simple calculator (+ -  *  /)*/
		
		
	            Scanner sc=new Scanner(System.in);
				System.out.println("-------A Simple Calculator for sum--------");
			    System.out.println("Enter  Number 1 for sum");
			    int num1= sc.nextInt();
			    System.out.println("Enter  Number 1 for sum");
			    int num2= sc.nextInt();
			    
			    int sum=num1+num2;
			    System.out.println("The sum of "+num1+" & "+num2+"is="+sum);
			    System.out.println("----------------------------------");
			    
			    System.out.println("-------A Simple Calculator for sub--------");
			    System.out.println("Enter  Number 1 for sub");
			    int num3= sc.nextInt();
			    System.out.println("Enter  Number 1 for sub");
			    int num4= sc.nextInt();
			    
			    int sub=num3-num4;
			    System.out.println("The sub of "+num3+" & "+num4+"is="+sub);
			    
			    
			    System.out.println("-------A Simple Calculator for mul--------");
			    System.out.println("Enter  Number 1 for mul");
			    int num5= sc.nextInt();
			    System.out.println("Enter  Number 1 for mul");
			    int num6= sc.nextInt();
			    
			    int mul=num5*num6;
			    System.out.println("The sub of "+num5+" & "+num6+"is="+mul);
			    
			    System.out.println("-------A Simple Calculator for div--------");
			    System.out.println("Enter  Number 1 for div");
			    int num7= sc.nextInt();
			    System.out.println("Enter  Number 1 for div");
			    int num8= sc.nextInt();
			    
			    int div=num7/num8;
			    System.out.println("The sub of "+num7+"&"+num8+"is="+div);
			    
			    
	}

}
