package mypack;
import java.util.Scanner;
public class Whileloop {

	public static void main(String[] args) {
		
		
		//While loop : execute a block of code as long as it is condition remains true
		
		Scanner sc=new Scanner(System.in);
		String name=" ";
		
		while(name.isBlank()) {
			System.out.print("Enter your name:  ");
			name=sc.nextLine();
		}
		System.out.println("Hello "+name);

	}

}
