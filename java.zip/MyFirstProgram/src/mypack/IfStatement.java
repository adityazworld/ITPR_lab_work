package mypack;
import java.util.Scanner;
public class IfStatement {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		

		int age;
		System.out.println("Enter the age :");
		age=sc.nextInt();
		
		if(age<0) {
			System.out.println("You are not  adult !");
		}
		else if(age>=18) {
			System.out.println("are you adult");
		}
		 
		else {
			System.out.println("You are not eligible for voting");
		}

	}

}
